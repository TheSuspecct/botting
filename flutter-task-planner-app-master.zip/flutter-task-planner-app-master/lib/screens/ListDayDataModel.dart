class ListDayDataModel{
  final String name, desc;
  ListDayDataModel(this.name, this.desc);
}